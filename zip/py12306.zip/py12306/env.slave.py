# -*- coding: utf-8 -*-
# 分布式子节点配置文件示例

# 分布式集群配置
CLUSTER_ENABLED = 1  # 集群状态
NODE_IS_MASTER = 0  # 是否是主节点
NODE_NAME = 'slave 1'  # 节点名称，不能重复
REDIS_HOST = 'localhost'  # Redis  host
REDIS_PORT = '6379'  # Redis  port
REDIS_PASSWORD = ''  # Redis  密码 没有可以留空

# 没了，其它配置会自动从主节点同步
