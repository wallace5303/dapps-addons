#! /bin/sh

cd /bin && ./BaiduPCS-Go