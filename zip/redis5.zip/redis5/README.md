## 配置信息

服务端口：6379

## 说明
1. 查看容器：```$ docker container ls```
2. 进入容器：
   ```
    docker exec -it dapps-redis5 /bin/sh

    # 查看信息
    redis-cli -v
   ```





