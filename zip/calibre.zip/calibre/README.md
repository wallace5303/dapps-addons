## 使用

安装后打开效果：

![](https://images.weserv.nl/?url=https://img04.sogoucdn.com/app/a/100520146/d68f00badc1b9c9df8f53bf42c037c32)

## 说明
- 更多读书资源：http://www.zoudupai.com/

## 软件效果

1. 
![](https://images.weserv.nl/?url=https://img02.sogoucdn.com/app/a/100520146/a070fbcb0d7fa1a778c51051b5a7bc04)

![](https://images.weserv.nl/?url=https://img04.sogoucdn.com/app/a/100520146/57cb24d7cbd7fd77a3a676dc1276f57b)


#### 本项目基于oldiy博客制作
    





