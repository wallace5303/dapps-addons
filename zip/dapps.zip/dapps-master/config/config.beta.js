'use strict';
// 本地环境-配置文件

exports.logger = {
  dir: './logs/beta',
};
