'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;

  // 反馈
  // router.get('/api/v1/feedback/send', controller.v1.feedback.send);
};
