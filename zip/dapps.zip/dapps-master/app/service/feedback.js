'use strict';

const BaseService = require('./base');

class FeedbackService extends BaseService {}

module.exports = FeedbackService;
