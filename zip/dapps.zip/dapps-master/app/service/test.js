'use strict';

const BaseService = require('./base');
const commonConfig = require('../config/commonConfig');
const utils = require('../utils/utils');
const moment = require('moment');
const _ = require('lodash');

class TestService extends BaseService {}

module.exports = TestService;
