## 使用

安装后打开效果：

![](https://images.weserv.nl/?url=https://img02.sogoucdn.com/app/a/100520146/e6353f952d3e188c3f73db7bc144344c)

## 说明
- 无

## 软件效果

1. 

![](https://images.weserv.nl/?url=https://img02.sogoucdn.com/app/a/100520146/fdf6acca822814c9f2376e4c3aab983b)

![](https://images.weserv.nl/?url=https://img03.sogoucdn.com/app/a/100520146/70cffcec74ead3432f3f8d62ef5f0771)

![](https://images.weserv.nl/?url=https://img02.sogoucdn.com/app/a/100520146/9a90d03ac7b02d3f2b5bc3d12d84729b)

#### 本项目基于oldiy的博客
    





