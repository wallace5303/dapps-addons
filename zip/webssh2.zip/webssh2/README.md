## 使用

安装后打开效果：

![](https://images.weserv.nl/?url=https://img03.sogoucdn.com/app/a/100520146/1b26a8c637374bfb36cfc7b00977df68)


## 更多用法

1. [查看文档](https://github.com/billchurch/WebSSH2)


本项目基于开源项目： [WebSSH2](https://github.com/billchurch/WebSSH2)
    





