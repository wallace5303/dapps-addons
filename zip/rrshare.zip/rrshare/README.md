## 使用

安装后打开效果：

![](https://i.loli.net/2019/11/18/XJnCOhUyGYPc7lz.png)

## 说明
- 解锁密码：123456
- 下载路径：./dapps/docker/addons/rrshare/data
- 注：dapps项目中的下载或保存路径，不能修改。
    
## 软件效果

1. 
![](https://i.loli.net/2019/11/18/l4PsZHD3MpNaCzF.png)
![](https://i.loli.net/2019/11/18/AwetvSfHosVC5ml.png)


本项目基于官方代码
    





