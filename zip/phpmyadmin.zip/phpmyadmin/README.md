### 效果图：

- 注：如果数据库在本机，将127.0.0.1:3306 改为 本机ip:3306


![](https://i.loli.net/2019/10/08/tElrUuz1pmoSCfG.png)

![](https://i.loli.net/2019/10/08/Y2DGjzJ4opiFueM.png)





