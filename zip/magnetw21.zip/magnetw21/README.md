## 资源搜索工具

### 这么好用的东西，分享给你的朋友吧

### 效果图：

![](https://i.loli.net/2019/10/18/Oz5jJbkAmvBPuWx.png)

![](https://i.loli.net/2019/10/18/RezxLJiOS5GuUtf.png)

