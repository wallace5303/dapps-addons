## 资源搜索工具

### 这么好用的东西，分享给你的朋友吧

### 效果图：

![](https://i.loli.net/2019/10/18/Oz5jJbkAmvBPuWx.png)

![](https://i.loli.net/2019/10/18/RezxLJiOS5GuUtf.png)


### 注：

1. 如果(360浏览器)页面空白，请将浏览器模式调整为谷歌内核（极速模式）
