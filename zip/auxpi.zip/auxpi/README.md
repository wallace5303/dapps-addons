## 使用

安装后打开效果：

![](https://i.loli.net/2019/11/18/FAMBR52tNpd8CeL.png)

## 默认用户
- 账号：auxpi@example.com
- 密码：12345678
    
## 效果

1. 上传
![](https://i.loli.net/2019/11/18/tiQDlHC5cqJWSId.png)

2. 图片管理
![](https://i.loli.net/2019/11/18/gHrbC7fywT8L9VE.png)

![](https://i.loli.net/2019/11/18/7ImfeRwjZJ45Eqp.png)


本项目基于开源项目： [auxpi](https://github.com/aimerforreimu/auxpi)