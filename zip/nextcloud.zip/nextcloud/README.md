## 使用

安装后打开效果：

![](https://i.loli.net/2019/11/26/NwzXVqpMrxlnk62.png)


## 说明
- 注：配置文件目录：./nextcloud/config
    
## 软件效果

1. 登录
 
    ![](https://i.loli.net/2019/11/26/VgqutamALdpYKHR.png)

2. 看视频
 
    ![](https://i.loli.net/2019/11/26/QuVIy4WTRNXfSw3.png)

3. 读文档
 
    ![](https://i.loli.net/2019/11/26/85HTGbL4jqy1pvX.png)

4. 手机端
 
    ![](https://i.loli.net/2019/11/26/i7AfDQm8ONuoITX.png)

5. 设置
 
    ![](https://i.loli.net/2019/11/26/6VIEGNxv84pAaTW.png) 


    





