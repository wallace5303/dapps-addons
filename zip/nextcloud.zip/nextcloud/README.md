## 使用

安装后打开效果：

![](https://images.weserv.nl/?url=https://img01.sogoucdn.com/app/a/100520146/5f69ab2244c0831180ddb3944c7c0bd7)


## 软件效果

1. 登录
 
    ![](https://images.weserv.nl/?url=https://img03.sogoucdn.com/app/a/100520146/51d64c64c93bc26376edf330e3c5662c)

2. 看视频
 
    ![](https://images.weserv.nl/?url=https://img02.sogoucdn.com/app/a/100520146/3a97ebadf8c8b25d899f2751b139acb2)

3. 读文档
 
    ![](https://images.weserv.nl/?url=https://img04.sogoucdn.com/app/a/100520146/08a10465324d706183b0543bb0ffe7ae)

4. 手机端
 
    ![](https://images.weserv.nl/?url=https://img01.sogoucdn.com/app/a/100520146/5bd8a3e98f359361ca673b1b382c6523)

5. 设置
 
    ![](https://images.weserv.nl/?url=https://img01.sogoucdn.com/app/a/100520146/f65cbe23d46858a2f63959cad4c8d2b9) 


    





