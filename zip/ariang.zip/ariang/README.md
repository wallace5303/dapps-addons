## 使用

安装完后，打开页面：

![](http://img02.shangguantv.com/pic/20191104144310.png)

将标注3，改为8011

## 文件保存位置：
    
    ./dapps/docker/addons/ariang/downloads 目录下

## 下载速度对比

![](https://i.loli.net/2019/11/04/RoxOCNnWEdaHFLw.png)

![](https://i.loli.net/2019/11/06/G5h1pMCSLD7RqQz.png)

本项目基于开源项目： [ariang](https://github.com/mayswind/AriaNg)





