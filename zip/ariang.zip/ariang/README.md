## 使用

安装完后，打开页面：

    ![](http://img02.shangguantv.com/pic/20191104144310.png)

    将标注3，改为8011

## 下载速度对比


## 文件保存位置：
    
    ./dapps/docker/addons/ariang/downloads 目录下




