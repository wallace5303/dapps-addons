## 配置信息

1. 默认用户名：root
2. 默认密码：123456
3. 端口：27017

## 说明
1. 查看容器：```$ docker container ls```
2. 进入容器：
   ```
    docker exec -it dapps-mongo34 /bin/bash
   ```



