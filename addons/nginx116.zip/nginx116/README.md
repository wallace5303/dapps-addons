## 配置信息

服务端口：80/443

## 说明
1. 查看容器：```$ docker container ls```
2. 进入容器：
   ```
    docker exec -it dapps-nginx116 /bin/sh

    # 查看信息
    nginx -v
   ```

### 说明

1. 文件目录为：./dapps/docker/www